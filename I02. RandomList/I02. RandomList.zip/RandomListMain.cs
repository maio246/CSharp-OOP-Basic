﻿public static class RandomListMain
{
    public static void Main()
    {

    }
}

