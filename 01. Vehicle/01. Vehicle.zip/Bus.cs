﻿public class Bus : Vehicle
{
    public Bus(double fuelQuantity, double fuelPerKm, double fuelCapacity)
        : base(fuelQuantity, fuelPerKm, fuelCapacity)
    { }

}

