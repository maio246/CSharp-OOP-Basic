﻿public abstract class Feline : Mammal
{
    public Feline(string animalName, string animalType, double animalWeight, string livingReagion)
        : base(animalName, animalType, animalWeight, livingReagion)
    {}
}

