﻿    public static class Stack
    {
        public static void Main()
        {

        }
    }
