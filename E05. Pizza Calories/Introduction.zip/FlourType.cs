﻿public enum FlourType
{
    wholegrain,
    white
}