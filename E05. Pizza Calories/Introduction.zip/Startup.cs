﻿using System;

public class Startup
{
    public static void Main()
    {
        try
        {
            var pizzaData = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            var pizzaName = pizzaData[1];
            Pizza pizza = new Pizza(pizzaName);

            var doughData = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            var flour = doughData[1];
            var bakingTechnique = doughData[2];
            var doughWeight = double.Parse(doughData[3]);

            Dough dough = new Dough(flour, bakingTechnique, doughWeight);

            pizza.Dough = dough;

            string toppingInfo;

            while ((toppingInfo = Console.ReadLine()) != "END")
            {
                var toppingData = toppingInfo.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                var toppingType = toppingData[1];
                var toppingWeight = double.Parse(toppingData[2]);
                Topping topping = new Topping(toppingType, toppingWeight);

                pizza.AddTopping(topping);
            }

            var totalPizzaCalories = pizza.TotalCalories();

            Console.WriteLine($"{pizza.Name} - {totalPizzaCalories:f2} Calories.");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}