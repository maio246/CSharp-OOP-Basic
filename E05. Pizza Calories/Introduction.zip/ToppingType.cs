﻿public enum ToppingType
{
    meat,
    veggies,
    cheese,
    sauce
}
