﻿using System;

public class Dough
{
    private const double BaseCaloriesPerGram = 2;
    private const int MinWieght = 1;
    private const int MaxWeight = 200;

    private string flour;
    private string bakingTechnique;
    private double weight;
    private double doughCalories;

    public Dough(string flour, string bakingTechnique, double weight)
    {
        this.Flour = flour;
        this.BakingTechnique = bakingTechnique;
        this.Weight = weight;
        this.DoughCalories = BaseCaloriesPerGram;
    }

    private string Flour
    {
        set
        {
            if (!Enum.TryParse(value.ToLower(), out FlourType flour))
            {
                throw new ArgumentException("Invalid type of dough.");
            }

            this.flour = value;
        }
    }

    private string BakingTechnique
    {
        set
        {
            if (value.ToLower() != "crispy" &&
                value.ToLower() != "chewy" &&
                value.ToLower() != "homemade")
            {
                throw new ArgumentException("Invalid type of dough.");
            }

            this.bakingTechnique = value;
        }
    }

    private double Weight
    {
        set
        {
            if (value < MinWieght || value > MaxWeight)
            {
                throw new ArgumentException($"Dough weight should be in the range [1..200].");
            }

            this.weight = value;
        }
    }

    public double DoughCalories
    {
        get
        {
            return this.doughCalories;
        }
        private set
        {
            double flourModifier = 1.0;
            double bakingModifier = 0.9;

            if (this.flour.ToLower().Equals("white"))
            {
                flourModifier = 1.5;
            }

            if (this.bakingTechnique.ToLower().Equals("homemade"))
            {
                bakingModifier = 1.0;
            }
            else if (this.bakingTechnique.ToLower().Equals("chewy"))
            {
                bakingModifier = 1.1;
            }

            var calories = (BaseCaloriesPerGram * this.weight) * flourModifier * bakingModifier;

            this.doughCalories = calories;
        }
    }
}
