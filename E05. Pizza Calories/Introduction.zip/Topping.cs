﻿using System;

public class Topping
{
    public const double BaseCaloriesPerGram = 2;

    private string toppingName;
    private double modifier;
    private double weight;
    private double caloriesPerGram;

    public Topping(string toppingType, double weight)
    {
        this.ToppingType = toppingType;
        this.Weight = weight;
        this.CaloriesPerGram = BaseCaloriesPerGram;
    }

    private string ToppingType
    {
        set
        {
            if (!Enum.TryParse(value.ToLower(), out ToppingType name))
            {
                throw new ArgumentException($"Cannot place {value} on top of your pizza.");
            }

            switch (name)
            {
                case global::ToppingType.meat:
                    this.modifier = 1.2;
                    break;
                case global::ToppingType.veggies:
                    this.modifier = 0.8;
                    break;
                case global::ToppingType.cheese:
                    this.modifier = 1.1;
                    break;
                case global::ToppingType.sauce:
                    this.modifier = 0.9;
                    break;
            }
            this.toppingName = value;
        }
    }

    private double Weight
    {
        set
        {
            if (value < 1 || value > 50)
            {
                throw new ArgumentException($"{this.toppingName} weight should be in the range [1..50].");
            }

            this.weight = value;
        }
    }

    public double CaloriesPerGram
    {
        get
        {
            return this.caloriesPerGram;
        }
        private set
        {
            this.caloriesPerGram = (BaseCaloriesPerGram *  this.weight) * this.modifier;
        }
    }
}
