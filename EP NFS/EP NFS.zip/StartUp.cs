﻿using System;

public static class StartUp
{
    public static void Main()
    {
        var engine = new Engine();
        engine.StartUp();
    }
}

