﻿public class Shapes
{
    static void Main()
    {
    }
}

