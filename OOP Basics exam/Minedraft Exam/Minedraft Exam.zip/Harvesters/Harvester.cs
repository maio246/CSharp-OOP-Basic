﻿using System;
using System.Text;

public abstract class Harvester
{
    public string id;
    public double oreOutput;
    public double energyRequirement;
    public string type; 

    protected Harvester(string id, double oreOutput, double energyRequirement)
    {
        this.Id = id;
        this.OreOutput = oreOutput;
        this.EnergyRequirement = energyRequirement;
    }

    public string Type
    {
        get { return this.type; }
        set { this.type = value; }
    }
    public double OreOutput
    {
        get { return this.oreOutput; }
        set
        {
            if (value < 0 )
            {
                throw new ArgumentException($"Harvester is not registered, because of it's OreOutput");
            }
            this.oreOutput = value;
        }
    }

    public string Id
    {
        get { return this.id; }
        set { this.id = value; }
    }

    public double EnergyRequirement
    {
        get { return this.energyRequirement; }
        set
        {
            if (value < 0 || value > 20000)
            {
                throw new ArgumentException("Harvester is not registered, because of it's EnergyRequirement");
            }
            this.energyRequirement = value;

        }
    }

    public override string ToString()
    {
        var harvesterBuilder = new StringBuilder();

        harvesterBuilder.AppendLine($"{this.type} Harvester - {this.id}");
        harvesterBuilder.AppendLine($"Ore Output: {this.oreOutput}");
        harvesterBuilder.AppendLine($"Energy Requirement: {this.energyRequirement}");

        return harvesterBuilder.ToString().Trim();
    }
}

